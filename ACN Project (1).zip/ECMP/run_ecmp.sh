sudo python ft.py -p 0.03 
sudo mn -c
sudo python clean.py


